/**
 * Standard API Response Structure
 * Ensures uniform JSON responses across all endpoints
 */
export class ApiResponse {
  constructor(statusCode, data, message = "Success") {
    this.statusCode = statusCode;
    this.success = statusCode < 400;
    this.message = message;
    this.data = data;
  }

  static success(res, data, message = "Operation successful", statusCode = 200) {
    return res.status(statusCode).json(new ApiResponse(statusCode, data, message));
  }

  static created(res, data, message = "Resource created successfully") {
    return res.status(201).json(new ApiResponse(201, data, message));
  }
}
